#ifndef TV_H
#define TV_H


#include "ets.h"


#ifdef __cplusplus
extern "C" {
#endif

void tv_init(void);
void tv_start(void);

#ifdef __cplusplus
}
#endif


#endif
