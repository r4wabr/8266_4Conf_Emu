#ifndef FILEMAN_H
#define FILEMAN_H


#include "ets.h"


int_fast16_t fileman (uint8_t type, uint_fast8_t Mode);


#endif
