#ifndef XLAT_H
#define XLAT_H


#include <inttypes.h>


extern const uint8_t xlat[];


#endif
