#ifndef MENU_H
#define MENU_H


#include "ets.h"


int_fast16_t menu_fileman (uint_fast8_t Load);

void menu(void);


#endif
