#ifndef CHECK_IMAGE_H
#define CHECK_IMAGE_H


#include <inttypes.h>


uint32_t check_image(uint32_t readpos);


#endif
