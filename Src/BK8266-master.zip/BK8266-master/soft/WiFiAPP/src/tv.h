#ifndef TV_H
#define TV_H


#include <os_type.h>


#ifdef __cplusplus
extern "C" {
#endif


extern uint8_t tv_empty_line[80];


void tv_init(void);


#ifdef __cplusplus
}
#endif


#endif
