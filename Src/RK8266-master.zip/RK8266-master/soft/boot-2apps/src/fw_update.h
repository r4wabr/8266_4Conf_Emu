#ifndef FW_UPDATE_H
#define FW_UPDATE_H


void fw_update(void);


#endif
