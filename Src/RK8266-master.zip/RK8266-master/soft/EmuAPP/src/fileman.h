#ifndef FILEMAN_H
#define FILEMAN_H


#include "ets.h"


int16_t fileman(uint8_t type, const char *text);


#endif
