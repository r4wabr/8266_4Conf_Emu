#ifndef MAIN_H
#define MAIN_H


#include "ets.h"


extern volatile uint8_t i8080_speed_K;


#endif
