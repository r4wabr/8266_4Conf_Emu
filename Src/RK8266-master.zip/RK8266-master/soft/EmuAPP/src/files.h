#ifndef FILES_H
#define FILES_H


#include "ets.h"


int16_t load_file(uint16_t n);


#endif
