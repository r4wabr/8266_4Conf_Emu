#ifndef REBOOT_H
#define REBOOT_H


#include "ets.h"


void reboot(uint32_t value);


#endif
