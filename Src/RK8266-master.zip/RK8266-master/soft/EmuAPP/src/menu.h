#ifndef MENU_H
#define MENU_H


#include "ets.h"


bool menu_fileman(void);

void menu(void);


#endif
